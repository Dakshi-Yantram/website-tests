# HIMS AUTOMATED TEST REPORT

Run ID: {{run_id}} | Date: {{time}} | Frontend SHA: {{frontend_sha}} | Backend SHA: {{backend_sha}} | Agent SHA: {{agent_sha}}
Environment: {{staging}} | Browser: {{browser}} | Roles tested: {{roles}}

## Executive summary
PASS {{pass}} | FAIL {{fail}} | BLOCKED {{blocked}} | NOT VERIFIED {{not_verified}} | NOT TESTED {{not_tested}} | SKIPPED {{skipped}}

## Coverage by module and role
| Module | Role | Planned | Passed | Failed | Blocked | Not verified |
|---|---|---:|---:|---:|---:|---:|
| OPD | doctor | {{n}} | {{n}} | {{n}} | {{n}} | {{n}} |

## Confirmed defects (descending P0-P3)
**{{finding_id}} {{title}}**
- Status/severity/confidence: {{status}} / {{severity}} / {{confidence}}
- Grounded source routes: {{source_ref}}
- Steps with fixture ID: {{repro}}
- Expected: {{expected}}
- Actual: {{actual}}
- API status/request-id/duration: {{http}}
- Evidence links: {{screenshot}} {{trace}} {{log}} (sanitized)
- Root cause: {{verified_or_unverified}}
- Fix recommendation: {{fix}}
- Rerun: {{rerun}}

## Blocked and not verified
{{reasons_not_counted_as_product_bugs}}

## Safety audit
Synthetic patient only: {{yes_no}} | Real charges avoided: {{yes_no}} | PHI redaction passed: {{yes_no}}

## Release gate decision
{{go_no_go_unknown}} with justification.
