# Hospital HIMS — Source-derived automated testing pack

**Snapshot:** 26 October 2026. Frontend HospitalDashboard-main and Backend HospitalBackend-master; agent website-tests-main.

## Scope and evidence

- 274 frontend `<Route path>` declarations (relative segments; route nesting matters). See `frontend_route_inventory.json`.
- 530 backend `router.route(...)` or `router.METHOD(...)` declarations found via static pattern matching. See `backend_endpoint_inventory.json`. These are NOT runtime-discovered or all effective endpoints; review mounting in `app.js`.
- 70 prioritized test specifications across 15 module groups; includes 14 function/middleware-level targets.
- This is a **test plan and machine-readable test specification**, NOT evidence that tests were executed or passed. All workflow assertions require implementation binding.

## Individual-function inventory

`function_test_inventory.json` identifies **7970 potential named functions** from frontend/backend code using static pattern matching, with source file/line and proposed test dimensions. This is a candidate inventory, not a guarantee of all callable functions or proof of implementation/test coverage. Prioritize exported business functions, controllers, validations, security and financial calculations; bind each to a proper unit test.

## Important agent compatibility blocker

The uploaded `website-tests-main/tests/test_07_workflows.py` defines Python `WORKFLOWS` directly; it **does not load YAML**. Its `config.py` only includes `reception` and `doctor` for the hospital app. This package therefore is **not drop-in executable** until Dakshi implements the loader/step engine and additional test-role configuration. Do not pretend to run or pass these tests using the existing code.

### Required implementation handoff

1. Change workflow discovery to read `workflows/*.yaml` using `yaml.safe_load`, validate `schema_version`, reject unknown keys, duplicate IDs, empty assertions or missing source anchors.
2. Add role credentials in CI secret store for `nurse_hospital`, `lab`, `radiology`, `pharmacy`, `finance`, `hr`, `hospital_admin`, `super_admin`. Verify real RBAC names before mapping them. Never place credentials in YAML.
3. Implement two execution adapters: **browser/e2e** with Playwright and **api/integration** with authenticated HTTP requests; **unit** targets use frontend test runner (e.g. Vitest) or backend Jest/Node test runner. Browser-only execution cannot test isolated functions reliably.
4. Resolve each `source_anchors` item to actual selectors, mounted API path, accepted request shape, permitted roles, and a deterministic outcome based on code. `steps` are source navigation hints, not executable DOM commands. Build executable mapped steps and verify them on staging.
5. Validate assertions against service/controller source (and documented business rules). Do not rely on `body text nonempty` or a toast to prove persistence. Use GET/reload and DB/API confirmation where authorized.
6. Block writes unless `ALLOW_WRITE_TESTS=true`, `TEST_ENV=staging`, synthetic dedicated tenant, and cleanup fixture IDs exist. NEVER auto-run discharge, real clinical orders, payments, payroll, prescriptions, irreversible OT transitions, or patient notifications without a controlled staging fixture and explicit approval.
7. CI status: fail on confirmed critical/high defects (P0/P1), distinguish `FAIL`, `PASS`, `BLOCKED`, `NOT_TESTED`, `NOT_VERIFIED` and `SKIPPED`. Blocked/unknown may fail release readiness but must not be described as product defects.
8. Produce one finding per distinct root incident; support deduplication by `(workflow_id, endpoint, assertion, normalized_error)` and attach redacted screenshots, traces, status codes, correlation IDs, timing and reproduction steps.
9. Use GitHub Actions read-only repository checkout; don't upload .env.production, tokens, database dumps, patient names or unredacted browser screenshots.

## Test status / coverage rules

- **PASS:** All required preconditions met, action executed, and independently verified assertions passed.
- **FAIL:** Reproducible application behavior contradicts a grounded expectation.
- **BLOCKED:** Missing role, fixture, environment, dependency or approved destructive-action permission.
- **NOT_VERIFIED:** UI action completed but assertion insufficient or intended business rule unspecified.
- **NOT_TESTED:** Explicitly excluded by safety/run scope.
- **SKIPPED:** Test excluded by configuration with documented reason.

### Severity

- **P0 critical:** clinical record mix-up, tenant/PHI leak, unauthorized clinical act, incorrect clinical safety gating, incorrect irreversible financial effects.
- **P1 high:** broken registration/admission, lost notes, wrong billing, critical module down.
- **P2 medium:** functional defect with workaround, incomplete validation.
- **P3 low:** visual/cosmetic/minor usability.

## Error report required sections

Run metadata (commit SHAs, frontend/backend versions, environment, browser, date, roles); coverage by module and role; summary counts; critical patient safety/security findings first; each incident with exact expected vs actual, sanitized reproduction steps, screenshot/trace, request/response IDs and rerun result; distinct app defects vs agent failures; not-covered and blocked cases; recommended fixes and retest outcomes. `sample_finding.json` is **fictional illustrative data**, not an observed bug.

### Example human-readable finding

**HIMS-OPD-0001 — SAMPLE ONLY — P0 — FAIL**

**Workflow:** OPD-002, Doctor. **Scenario:** Save a synthetic encounter note then reopen.

**Expected:** Note persists for the correct patient/timeline and is absent from other patients.

**Actual (fictional illustration):** After save, note appears under another timeline.

**Evidence:** Redacted screenshot + Playwright trace + request correlation ID; reproduce 2/2.

**Impact:** Patient safety and privacy. **Action:** investigate timeline ID binding; add server-side ownership assertions; rerun regression.

## Priorities & recommended execution sequence

1. P0 read-only RBAC/tenant/patient isolation; authentication and sessions; safe API GET smoke.
2. P0 staged synthetic write workflows: reception registration → OPD encounter → doctor documentation; confirm patient IDs remain consistent.
3. P0 emergency triage → IPD, mother/newborn linkage, OT safety gate (controlled fixtures).
4. P0 laboratory → pharmacy → finance order/result/dispense/billing transitions (synthetic only).
5. Remaining modules: radiology, HR, admin, reports, audit, performance and resilience.

## Coverage caveats

Front-end routes prove screens/routes are declared, not that every action exists/works at runtime. Backend route declarations prove route code exists, not response shapes or valid transitions. Module names/roles are logical test personas and must be mapped to actual app permissions. Source code includes `.env.production` in the uploaded frontend ZIP — DO NOT distribute this source archive or its contents in reports. This pack deliberately contains no environment file values.

## Contents

- `agent_config.yaml`: execution guardrails + machine-readable report paths.
- `workflows/*.yaml`: role-specific functional scenarios, negative/boundary cases, source anchors, intended assertions.
- `function_test_inventory.json`: function targets for granular test authoring.
- `frontend_route_inventory.json`: raw declared frontend route segments.
- `backend_endpoint_inventory.json`: raw backend declarations requiring mounted-path/method review.
- `sample_finding.json`: sample error report object.
- `report_template.md`: report structure with fictional sample.
