"""Example validation/loader for Dakshi; NOT an executable Playwright step interpreter."""
from pathlib import Path
import yaml

def read_specs(root='workflows'):
    ids = set()
    for fn in sorted(Path(root).glob('*.yaml')):
        obj = yaml.safe_load(fn.read_text(encoding='utf-8'))
        if obj.get('schema_version') != 'hims.agent.workflow.v1':
            raise ValueError(f'Wrong version: {fn}')
        for item in obj['workflows']:
            if item['id'] in ids: raise ValueError(f'Duplicate ID {item["id"]}')
            ids.add(item['id'])
            if not item['assertions']: raise ValueError(f'No assertions: {item["id"]}')
            yield item

if __name__ == '__main__':
    tests = list(read_specs())
    print(f'{len(tests)} workflow specifications loaded; execution adapter required')
